from django.urls import path
from . import views
from accounts import views as account_views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path("rent/<int:car_id>/", views.rent_car, name="rent_car"),
    path("my-rentals/", views.my_rentals, name="my_rentals"),
    path("return/<int:rental_id>/", views.return_car, name="return_car"),
]
