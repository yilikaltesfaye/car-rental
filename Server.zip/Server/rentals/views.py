from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from catalog.models import CarModel, CarInstance
from .models import Rental
from .forms import RentalForm
from django.contrib import messages

@login_required
def rent_car(request, car_id):
    car = get_object_or_404(CarModel, id=car_id)

    available_instance = car.instances.filter(status="available").first()

    # if not available_instance:
    #     return render(request, "rentals/no_available.html", {"car": car})
    if not available_instance:
        messages.error(request, "Sorry, no cars available.")
        return redirect("home")
    
    if request.method == "POST":
        form = RentalForm(request.POST, request.FILES)
        # if form.is_valid():
        #     rental = form.save(commit=False)
        #     rental.user = request.user
        #     rental.car = car
        #     rental.car_instance = available_instance
        #     rental.status = "active"
        #     rental.save()
        #     # mark car instance as rented
        #     instance = car.instances.first()
        #     if instance:
        #         instance.status = "rented"
        #         instance.save()
        #     return redirect("my_rentals")
        if form.is_valid():
            start_date = form.cleaned_data["start_date"]
            end_date = form.cleaned_data["end_date"]

            # 1. Validate date range
            if end_date <= start_date:
                messages.error(request, "End date must be after start date.")
                return render(request, "rentals/rent.html", {"form": form, "car": car})

            # 2. Prevent overlapping rentals
            overlap = Rental.objects.filter(
                car_instance=available_instance,
                status="active",
                start_date__lt=end_date,
                end_date__gt=start_date
            ).exists()

            if overlap:
                messages.error(request, "This car is already rented for those dates.")
                return render(request, "rentals/rent.html", {"form": form, "car": car})

            # 3. Save rental
            rental = form.save(commit=False)
            rental.user = request.user
            rental.car = car
            rental.car_instance = available_instance
            rental.status = "active"
            rental.save()

            available_instance.status = "rented"
            available_instance.save()

            messages.success(request, f"You rented {car.model_name} successfully!")
            return redirect("my_rentals")
    else:
        form = RentalForm()
    return render(request, "rentals/rent_car.html", {"form": form, "car": car})

@login_required
def my_rentals(request):
    rentals = Rental.objects.filter(user=request.user)
    return render(request, "rentals/my_rentals.html", {"rentals": rentals})



@login_required
def return_car(request, rental_id):
    rental = get_object_or_404(Rental, id=rental_id, user=request.user)
    if rental.status == "active":
        rental.status = "completed"
        rental.save()
        # mark one rented instance back to available
        instance = rental.car_instance
        if instance and instance.status == "rented":
            instance.status = "available"
            instance.save()
    return redirect("my_rentals")


