from django.db import models

from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
# from django.conf import settings
from django.conf import settings
from catalog.models import CarModel, CarInstance 

class Category(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

class CarModel(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    model_name = models.CharField(max_length=100)
    daily_price = models.DecimalField(max_digits=8, decimal_places=2)
    photo = models.ImageField(upload_to="cars/")
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.model_name} ({self.category.name})"



from django.db import models
from django.contrib.auth.models import User
from catalog.models import CarModel

class CarInstance(models.Model):
    car_model = models.ForeignKey(CarModel, on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=20, choices=[
        ("available", "Available"),
        ("rented", "Rented"),
        ("out_of_service", "Out of Service"),
    ], default="available")

    def __str__(self):
        return f"{self.car_model.model_name} - {self.status}"

class Rental(models.Model):
    # user = models.ForeignKey(User, on_delete=models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    car = models.ForeignKey(CarModel, on_delete=models.CASCADE)
    car_instance = models.ForeignKey(CarInstance, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    license_image = models.ImageField(upload_to="licenses/", default="licenses/default.png")
    status = models.CharField(max_length=20, choices=[
        ("confirmed", "Confirmed"),
        ("returned", "Returned"),
        ("cancelled", "Cancelled"),
        ("active", "Active"), 
        ("completed", "Completed")
    ], default="confirmed")

    def __str__(self):
        return f"{self.user.username} rented {self.car_instance.car_model.model_name}"

class RentalDocument(models.Model):
    rental = models.ForeignKey(Rental, on_delete=models.CASCADE)
    license_upload = models.ImageField(upload_to="licenses/")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"License for {self.rental.user.username}"


@receiver(post_save, sender=CarModel)
def create_car_instances(sender, instance, created, **kwargs):
    if created:
        for _ in range(instance.quantity):
            CarInstance.objects.create(car_model=instance, status="available")