from django.contrib import admin
from .models import CarInstance, Rental, RentalDocument

admin.site.register(CarInstance)
admin.site.register(Rental)
admin.site.register(RentalDocument)
