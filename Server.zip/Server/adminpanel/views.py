from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from catalog.models import CarModel
from rentals.models import Rental
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render, redirect, get_object_or_404
from rentals.models import Rental
from catalog.models import CarInstance
from catalog.models import CarModel, CarInstance, Category
from .forms import CarForm, CategoryForm

@staff_member_required
def dashboard(request):
    total_cars = CarModel.objects.count()
    total_rentals = Rental.objects.count()
    active_rentals = Rental.objects.filter(status="active").count()
    return render(request, "adminpanel/dashboard.html", {
        "total_cars": total_cars,
        "total_rentals": total_rentals,
        "active_rentals": active_rentals,
    })


from django.contrib.admin.views.decorators import staff_member_required
from rentals.models import Rental

@staff_member_required
def rental_summary(request):
    rentals = Rental.objects.all()
    return render(request, "adminpanel/rental_summary.html", {"rentals": rentals})




@staff_member_required
def mark_returned(request, rental_id):
    rental = get_object_or_404(Rental, id=rental_id)
    if rental.status == "active":
        rental.status = "completed"
        rental.save()
        # increment car instance back to available
        instance = rental.car.instances.filter(status="rented").first()
        if instance:
            instance.status = "available"
            instance.save()
    return redirect("rental_summary")





@staff_member_required
def manage_cars(request):
    cars = CarModel.objects.all()
    if request.method == "POST":
        form = CarForm(request.POST, request.FILES)
        if form.is_valid():
            car = form.save()
            # create instances
            for _ in range(form.cleaned_data["number_of_instances"]):
                CarInstance.objects.create(car=car, status="available")
            return redirect("manage_cars")
    else:
        form = CarForm()
    return render(request, "adminpanel/manage_cars.html", {"cars": cars, "form": form})

@staff_member_required
def delete_car(request, car_id):
    car = get_object_or_404(CarModel, id=car_id)
    car.delete()
    return redirect("manage_cars")

@staff_member_required
def manage_categories(request):
    categories = Category.objects.all()
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("manage_categories")
    else:
        form = CategoryForm()
    return render(request, "adminpanel/manage_categories.html", {"categories": categories, "form": form})