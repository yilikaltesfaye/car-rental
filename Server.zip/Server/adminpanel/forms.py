from django import forms
from catalog.models import CarModel, Category

class CarForm(forms.ModelForm):
    number_of_instances = forms.IntegerField(min_value=1)

    # class Meta:
    #     model = CarModel
    #     fields = ["unique_id", "category", "model_name", "daily_rate", "image"]

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ["name"]
