from django.urls import path
from . import views

urlpatterns = [
    path("dashboard/", views.dashboard, name="admin_dashboard"),
    path("rentals/", views.rental_summary, name="rental_summary"),
    path("rentals/return/<int:rental_id>/", views.mark_returned, name="mark_returned"),
     path("cars/", views.manage_cars, name="manage_cars"),
    path("cars/delete/<int:car_id>/", views.delete_car, name="delete_car"),
    path("categories/", views.manage_categories, name="manage_categories"),
]
