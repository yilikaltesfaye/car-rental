from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("category/<int:category_id>/", views.cars_by_category, name="cars_by_category"),
    path("car/<int:car_id>/", views.car_detail, name="car_detail"),
    # path("car/<int:car_id>/rent/", views.rent_car, name="rent_car"),

]
