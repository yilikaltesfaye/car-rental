from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import CarModel, CarInstance

@receiver(post_save, sender=CarModel)
def create_car_instances(sender, instance, created, **kwargs):
    if created:
        for _ in range(instance.quantity)>0:
            CarInstance.objects.create(car_model=instance, status="available")
