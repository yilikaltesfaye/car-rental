from django.db import models

from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

class CarModel(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="cars")
    model_name = models.CharField(max_length=100)
    daily_price = models.DecimalField(max_digits=8, decimal_places=2)
    photo = models.ImageField(upload_to="cars/")
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.model_name} ({self.category.name})"

class CarInstance(models.Model):  #availability tracker
    car_model = models.ForeignKey(
        CarModel,
        on_delete=models.CASCADE,
        related_name="catalog_instances"   # 👈 unique name
    )
    status = models.CharField(
        max_length=20,
        choices=[("available", "Available"), ("rented", "Rented")]
    )

    def __str__(self):
        return f"{self.car_model.model_name} - {self.status}"
