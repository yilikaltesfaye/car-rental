from django.contrib import admin
from .models import Category, CarModel, CarInstance

admin.site.register(Category)
admin.site.register(CarModel)
admin.site.register(CarInstance)
