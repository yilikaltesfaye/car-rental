from django.shortcuts import render, get_object_or_404
from .models import Category, CarModel

# def home(request):
#     categories = Category.objects.all()
#     sample_cars = CarModel.objects.all()  # show 4 sample cars
#     return render(request, "home.html", {
#         "categories": categories,
#         "sample_cars": sample_cars
#     })
from django.shortcuts import render
from catalog.models import CarModel
from django.db.models import Count, Q

def home(request):
    categories = Category.objects.all()
    cars = CarModel.objects.annotate(
        available_count=Count("catalog_instances", filter=Q(catalog_instances__status="available"))
    )
    return render(request, "home.html", {
        "categories": categories,
        "cars": cars,
    })
    # cars = CarModel.objects.all()

    # add available_count dynamically for the template
    # for car in cars:
    #     try:
    #         car.available_count = car.carinstance_set.filter(status="available").count()
    #     except:
    #         car.available_count = 0
    # for car in cars:
    #     car.available_count = car.catalog_instances.filter(status="available").count()
    
    # return render(request, "home.html", {
    #     "cars": cars,
    #     "categories": [],   # add if needed
    # })


def cars_by_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    cars = CarModel.objects.filter(category=category)
    for car in cars:
        car.available_count = car.catalog_instances.filter(status="available").count()
    return render(request, "cars_by_category.html", {
        "category": category,
        "cars": cars
    })

def car_detail(request, car_id):
    car = get_object_or_404(CarModel, id=car_id)
    available_count = car.catalog_instances.filter(status="available").count()
    return render(request, "car_detail.html", {
        "car": car,
        "available_count": available_count,
    })


def rent_car(request, car_id):
    car = get_object_or_404(CarModel, id=car_id)
    instance = car.catalog_instances.filter(status="available").first()
    if instance:
        instance.status = "rented"
        instance.save()
        message = f"You rented {car.model_name} successfully!"
    else:
        message = "Sorry, no cars available."
    return render(request, "rent_result.html", {"message": message})
