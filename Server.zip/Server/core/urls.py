from django.conf import settings
from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static


urlpatterns = [
    
    path('admin/', admin.site.urls),
    path('auth/', include('user.urls', namespace='user')),
    path("api/catalog/", include("catalog.urls")),
    path("api/rentals/", include("rentals.urls")),
    path("api/adminpanel/", include("adminpanel.urls")),
    path("api/accounts/", include("accounts.urls")),
    path("accounts/", include("django.contrib.auth.urls")),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)