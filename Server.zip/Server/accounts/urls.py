from django.urls import path
from django.contrib.auth import views as auth_views
from .views import RegisterAPI, LoginAPI, LogoutAPI, ProfileAPI
from . import views

urlpatterns = [
    # path("signup/", views.signup, name="signup"),
    # path("login/", auth_views.LoginView.as_view(template_name="login.html"), name="login"),
    # path("logout/", auth_views.LogoutView.as_view(next_page="home"), name="logout"),
    # path("profile/", views.profile, name="profile"),
    path("register/", RegisterAPI.as_view(), name="register"),
    path("login/", LoginAPI.as_view(), name="login"),
    path("logout/", LogoutAPI.as_view(), name="logout"),
    path("profile/", ProfileAPI.as_view(), name="profile"),
]


# urlpatterns = [
#     path("admin/", admin.site.urls),
#     path("accounts/", include("django.contrib.auth.urls")),   # login/logout
#     path("accounts/", include("accounts.urls")),              # signup
#     path("", include("catalog.urls")),                        # home
# ]
