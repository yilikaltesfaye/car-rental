from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework.authtoken.models import Token
from .models import Profile

# -------------------
# Signup API
# -------------------
class RegisterAPI(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        full_name = request.data.get("fullname")
        address = request.data.get("address")
        phone = request.data.get("phone")

        if not username or not password:
            return Response({"error": "Username and password required"}, status=status.HTTP_400_BAD_REQUEST)

        if User.objects.filter(username=username).exists():
            return Response({"error": "Username already taken"}, status=status.HTTP_400_BAD_REQUEST)

        # Create user
        user = User.objects.create_user(username=username, password=password)

        # Attach profile info
        profile, _ = Profile.objects.get_or_create(user=user)
        profile.full_name = full_name
        profile.address = address
        profile.phone_number = phone
        profile.save()

        return Response({"message": "User created successfully"}, status=status.HTTP_201_CREATED)


# -------------------
# Login API
# -------------------
class LoginAPI(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")

        user = authenticate(username=username, password=password)
        if user:
            token, _ = Token.objects.get_or_create(user=user)
            login(request, user)  # optional: logs user into Django session
            return Response({"token": token.key, "username": user.username}, status=status.HTTP_200_OK)

        return Response({"error": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)


# -------------------
# Logout API
# -------------------
class LogoutAPI(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        # Delete token to invalidate
        request.user.auth_token.delete()
        logout(request)
        return Response({"message": "Logged out successfully"}, status=status.HTTP_200_OK)


# -------------------
# Profile API
# -------------------
class ProfileAPI(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile = request.user.profile
        data = {
            "username": request.user.username,
            "full_name": profile.full_name,
            "address": profile.address,
            "phone_number": profile.phone_number,
        }
        return Response(data, status=status.HTTP_200_OK)

# from django.shortcuts import render

# from django.shortcuts import render, redirect
# from django.contrib.auth import login
# from .forms import CustomUserCreationForm

# from django.shortcuts import render
# from django.contrib.auth.decorators import login_required



# from django.shortcuts import render, redirect
# from django.contrib.auth import login
# from .forms import CustomUserCreationForm
# from .models import Profile

# def signup(request):
#     if request.method == "POST":
#         form = CustomUserCreationForm(request.POST)
#         if form.is_valid():
#             user = form.save()

#             # Always ensure one profile per user
#             profile, _ = Profile.objects.get_or_create(user=user)
#             profile.full_name = form.cleaned_data.get("full_name")
#             profile.address = form.cleaned_data.get("address")
#             profile.phone_number = form.cleaned_data.get("phone_number")
#             profile.save()

#             # Log in immediately and redirect
#             login(request, user)
#             return redirect("home")
#     else:
#         form = CustomUserCreationForm()
#     return render(request, "registration/signup.html", {"form": form})






# @login_required
# def profile(request):
#     return render(request, "registration/profile.html", {"profile": request.user.profile})