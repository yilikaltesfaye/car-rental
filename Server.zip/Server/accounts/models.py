# from django.db import models

# from django.contrib.auth.models import User
# from django.db import models

# class Profile(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     full_name = models.CharField(max_length=100)
#     address = models.TextField()
#     phone_number = models.CharField(max_length=15)

#     def __str__(self):
#         return self.full_name

# from django.db.models.signals import post_save
# from django.dispatch import receiver
# # This ensures every new user automatically has a Profile
# @receiver(post_save, sender=User)
# def create_profile(sender, instance, created, **kwargs):
#     if created:
#         Profile.objects.create(user=instance)


from django.db import models
# from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField

# from Server.core import settings
from django.conf import settings


class Profile(models.Model):
    # user = models.OneToOneField(User, on_delete=models.CASCADE)
    # user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='profiles')
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="accounts_profile")
    full_name = models.CharField(max_length=100, blank=True)
    address = models.TextField(blank=True)
    phone_number = PhoneNumberField(region="ET") 
    # phone_number = models.CharField(max_length=15, blank=True)

    def __str__(self):
        return self.full_name if self.full_name else self.user.username



# from django.db.models.signals import post_save
# from django.dispatch import receiver

# @receiver(post_save, sender=User)
# def create_user_profile(sender, instance, created, **kwargs):
#     if created:
#         Profile.objects.create(user=instance)

# @receiver(post_save, sender=User)
# def save_user_profile(sender, instance, **kwargs):
#     instance.profile.save()
