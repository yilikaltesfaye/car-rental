from django import forms

import re
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile
from phonenumber_field.formfields import PhoneNumberField

class CustomUserCreationForm(UserCreationForm):
    full_name = forms.CharField(max_length=100, required=True)
    address = forms.CharField(widget=forms.Textarea, required=True)
    phone_number = PhoneNumberField(region="ET")
    # phone_number = forms.CharField(max_length=15, required=True)

    class Meta:
        model = User
        fields = ("username", "password1", "password2", "full_name", "address", "phone_number")


    def clean_phone_number(self):
        phone = self.cleaned_data.get("phone_number")
        if phone:
            phone_str = str(phone)  # convert PhoneNumber object to string
            if not re.match(r'^\+?\d{9,15}$', phone_str):
                raise forms.ValidationError("Enter a valid phone number (9–15 digits, optional +).")
        return phone


    def clean_address(self):
        address = self.cleaned_data.get("address")
        # Example: enforce minimum length
        if len(address) < 10:
            raise forms.ValidationError("Address must be at least 10 characters long.")
        return address

    def save(self, commit=True):
        user = super().save(commit)
        Profile.objects.create(
            user=user,
            full_name=self.cleaned_data["full_name"],
            address=self.cleaned_data["address"],
            phone_number=self.cleaned_data["phone_number"],
        )
        return user

# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.models import User
# from .models import Profile

# class CustomUserCreationForm(UserCreationForm):
#     full_name = forms.CharField(max_length=100, required=True)
#     address = forms.CharField(widget=forms.Textarea, required=True)
#     phone_number = forms.CharField(max_length=15, required=True)

#     class Meta:
#         model = User
#         fields = ("username", "password1", "full_name", "address", "phone_number")

#     def save(self, commit=True):
#         user = super().save(commit)
#         profile = Profile.objects.create(
#             user=user,
#             full_name=self.cleaned_data["full_name"],
#             address=self.cleaned_data["address"],
#             phone_number=self.cleaned_data["phone_number"],
#         )
#         return user
